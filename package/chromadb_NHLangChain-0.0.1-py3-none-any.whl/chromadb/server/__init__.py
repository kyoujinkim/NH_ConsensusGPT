from abc import ABC, abstractmethod


class Server(ABC):
    def __init__(self, settings):
        pass
